#!/bin/bash
cd $postwrf_dir/modules
ncl separation.ncl > /dev/null