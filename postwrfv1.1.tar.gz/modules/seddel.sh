#!/bin/bash
sed '/added_new_line_by_sed/ d' extract.ncl > extractdel
mv extractdel extract.ncl
